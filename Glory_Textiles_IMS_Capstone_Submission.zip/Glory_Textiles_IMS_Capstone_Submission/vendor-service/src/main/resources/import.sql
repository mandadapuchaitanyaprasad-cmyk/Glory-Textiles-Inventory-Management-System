INSERT INTO vendor (vendor_id, vendor_name, contact_number, email, address, city) VALUES (101, 'Vardhman Textiles Ltd', '9876543210', 'contact@vardhman.com', '12 Industrial Area', 'Ludhiana');
INSERT INTO vendor (vendor_id, vendor_name, contact_number, email, address, city) VALUES (102, 'Raymond Cotton Mills', '9876543211', 'supplies@raymond.com', '45 Mill Road', 'Mumbai');
INSERT INTO vendor (vendor_id, vendor_name, contact_number, email, address, city) VALUES (103, 'Arvind Yarns Ltd', '9876543212', 'sales@arvind.com', '88 Fabric Zone', 'Ahmedabad');
INSERT INTO vendor (vendor_id, vendor_name, contact_number, email, address, city) VALUES (104, 'Welspun India', '9876543213', 'orders@welspun.com', '101 Silk Park', 'Surat');
INSERT INTO vendor (vendor_id, vendor_name, contact_number, email, address, city) VALUES (105, 'Trident Group', '9876543214', 'info@trident.com', '55 Cotton Hub', 'Coimbatore');
