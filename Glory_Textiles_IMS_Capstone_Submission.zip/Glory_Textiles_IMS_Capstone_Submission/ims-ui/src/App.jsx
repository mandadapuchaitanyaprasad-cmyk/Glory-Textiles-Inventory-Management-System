import React, { useState, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import PurchaseEntryForm from './components/PurchaseEntryForm';
import VendorReport from './components/VendorReport';
import DateRangeReport from './components/DateRangeReport';

// Initial Mock Microservices Data (Fallback if local REST endpoints aren't running)
const INITIAL_VENDORS = [
  { vendorId: 101, vendorName: 'Vardhman Textiles Ltd', contactNumber: '9876543210', email: 'contact@vardhman.com', address: '12 Industrial Area', city: 'Ludhiana' },
  { vendorId: 102, vendorName: 'Raymond Cotton Mills', contactNumber: '9876543211', email: 'supplies@raymond.com', address: '45 Mill Road', city: 'Mumbai' },
  { vendorId: 103, vendorName: 'Arvind Yarns Ltd', contactNumber: '9876543212', email: 'sales@arvind.com', address: '88 Fabric Zone', city: 'Ahmedabad' },
  { vendorId: 104, vendorName: 'Welspun India', contactNumber: '9876543213', email: 'orders@welspun.com', address: '101 Silk Park', city: 'Surat' },
  { vendorId: 105, vendorName: 'Trident Group', contactNumber: '9876543214', email: 'info@trident.com', address: '55 Cotton Hub', city: 'Coimbatore' }
];

const INITIAL_MATERIALS = [
  { materialId: 201, materialName: 'Organic Egyptian Cotton', materialCategory: 'Yarn', materialType: 'Natural Fiber', unit: 'Kg', unitPrice: 450 },
  { materialId: 202, materialName: 'Mulberry Silk Thread', materialCategory: 'Yarn', materialType: 'Luxury Silk', unit: 'Meters', unitPrice: 1250 },
  { materialId: 203, materialName: 'Polyester Blend Fabric', materialCategory: 'Fabric', materialType: 'Synthetic', unit: 'Meters', unitPrice: 180 },
  { materialId: 204, materialName: 'Refined Denim Weave', materialCategory: 'Fabric', materialType: 'Woven Denim', unit: 'Meters', unitPrice: 320 },
  { materialId: 205, materialName: 'Linen Flax Fibre', materialCategory: 'Raw Material', materialType: 'Plant Fiber', unit: 'Kg', unitPrice: 600 }
];

const INITIAL_PURCHASES = [
  { purchaseId: 301, vendorId: 101, vendorName: 'Vardhman Textiles Ltd', materialId: 201, materialName: 'Organic Egyptian Cotton', quantity: 100, unitPrice: 450, totalPrice: 45000, purchaseDate: '2026-08-15' },
  { purchaseId: 302, vendorId: 102, vendorName: 'Raymond Cotton Mills', materialId: 203, materialName: 'Polyester Blend Fabric', quantity: 250, unitPrice: 180, totalPrice: 45000, purchaseDate: '2026-08-20' },
  { purchaseId: 303, vendorId: 101, vendorName: 'Vardhman Textiles Ltd', materialId: 204, materialName: 'Refined Denim Weave', quantity: 150, unitPrice: 320, totalPrice: 48000, purchaseDate: '2026-08-28' },
  { purchaseId: 304, vendorId: 103, vendorName: 'Arvind Yarns Ltd', materialId: 202, materialName: 'Mulberry Silk Thread', quantity: 50, unitPrice: 1250, totalPrice: 62500, purchaseDate: '2026-09-01' },
  { purchaseId: 305, vendorId: 104, vendorName: 'Welspun India', materialId: 205, materialName: 'Linen Flax Fibre', quantity: 300, unitPrice: 600, totalPrice: 180000, purchaseDate: '2026-09-05' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [vendors, setVendors] = useState(INITIAL_VENDORS);
  const [materials, setMaterials] = useState(INITIAL_MATERIALS);
  const [purchases, setPurchases] = useState(INITIAL_PURCHASES);

  // Try fetching live data from microservices if running locally
  useEffect(() => {
    fetch('http://localhost:8081/vendor/all')
      .then(res => res.json())
      .then(data => data && data.length > 0 && setVendors(data))
      .catch(() => console.log('Using default VendorService data'));

    fetch('http://localhost:8082/material/all')
      .then(res => res.json())
      .then(data => data && data.length > 0 && setMaterials(data))
      .catch(() => console.log('Using default MaterialService data'));

    fetch('http://localhost:8083/inventory/all')
      .then(res => res.json())
      .then(data => data && data.length > 0 && setPurchases(data))
      .catch(() => console.log('Using default ImsService data'));
  }, []);

  const handleAddPurchase = (newEntry) => {
    setPurchases([newEntry, ...purchases]);
    // Also post to live endpoint if available
    fetch('http://localhost:8083/inventory/purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newEntry)
    }).catch(() => console.log('Logged locally'));
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="app-header">
        <div className="logo-section">
          <div className="logo-badge">GT</div>
          <div className="logo-text">
            <h1>Glory Textiles</h1>
            <p>Inventory Management System (IMS Capstone)</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div className="status-pill">
            <div className="status-dot"></div>
            <span>Microservices Online</span>
          </div>

          <nav className="nav-tabs">
            <button 
              className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
              onClick={() => setActiveTab('dashboard')}
            >
              Dashboard
            </button>
            <button 
              className={`tab-btn ${activeTab === 'purchase' ? 'active' : ''}`}
              onClick={() => setActiveTab('purchase')}
            >
              + Purchase Entry
            </button>
            <button 
              className={`tab-btn ${activeTab === 'vendor-report' ? 'active' : ''}`}
              onClick={() => setActiveTab('vendor-report')}
            >
              Vendor Report
            </button>
            <button 
              className={`tab-btn ${activeTab === 'date-report' ? 'active' : ''}`}
              onClick={() => setActiveTab('date-report')}
            >
              Date Range Report
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main>
        {activeTab === 'dashboard' && (
          <Dashboard 
            purchases={purchases} 
            vendors={vendors} 
            materials={materials} 
            onNavigate={(tab) => setActiveTab(tab)} 
          />
        )}

        {activeTab === 'purchase' && (
          <PurchaseEntryForm 
            vendors={vendors} 
            materials={materials} 
            onAddPurchase={handleAddPurchase} 
          />
        )}

        {activeTab === 'vendor-report' && (
          <VendorReport 
            purchases={purchases} 
            vendors={vendors} 
          />
        )}

        {activeTab === 'date-report' && (
          <DateRangeReport 
            purchases={purchases} 
          />
        )}
      </main>
    </div>
  );
}
