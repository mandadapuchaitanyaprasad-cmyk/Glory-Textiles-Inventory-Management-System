import React, { useState } from 'react';

export default function DateRangeReport({ purchases }) {
  const [startDate, setStartDate] = useState('2026-08-01');
  const [endDate, setEndDate] = useState('2026-09-30');

  const filteredPurchases = purchases.filter(p => {
    if (!p.purchaseDate) return true;
    return p.purchaseDate >= startDate && p.purchaseDate <= endDate;
  });

  const totalPeriodSpend = filteredPurchases.reduce((sum, p) => sum + (p.totalPrice || 0), 0);
  const totalItemsProcured = filteredPurchases.reduce((sum, p) => sum + (p.quantity || 0), 0);

  return (
    <div className="panel-card">
      <div className="panel-title">
        <span>Date Range Purchase Report</span>
      </div>

      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '16px',
        alignItems: 'flex-end',
        background: 'rgba(15, 23, 42, 0.6)',
        padding: '18px 24px',
        borderRadius: '12px',
        border: '1px solid var(--bg-card-border)',
        marginBottom: '24px'
      }}>
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label>Start Date</label>
          <input 
            type="date" 
            className="form-input" 
            value={startDate} 
            onChange={(e) => setStartDate(e.target.value)} 
          />
        </div>

        <div className="form-group" style={{ marginBottom: 0 }}>
          <label>End Date</label>
          <input 
            type="date" 
            className="form-input" 
            value={endDate} 
            onChange={(e) => setEndDate(e.target.value)} 
          />
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', gap: '20px' }}>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Orders Found</div>
            <div style={{ fontWeight: '700', fontSize: '1.2rem', color: 'var(--text-main)' }}>
              {filteredPurchases.length}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Total Value Procured</div>
            <div style={{ fontWeight: '700', fontSize: '1.2rem', color: 'var(--accent-emerald)' }}>
              ₹{totalPeriodSpend.toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      </div>

      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Purchase Date</th>
              <th>PO ID</th>
              <th>Vendor Name</th>
              <th>Material Name</th>
              <th>Quantity</th>
              <th>Unit Price (₹)</th>
              <th>Total Cost (₹)</th>
            </tr>
          </thead>
          <tbody>
            {filteredPurchases.length > 0 ? (
              filteredPurchases.map(p => (
                <tr key={p.purchaseId}>
                  <td><strong>{p.purchaseDate}</strong></td>
                  <td>#PO-{p.purchaseId}</td>
                  <td>{p.vendorName}</td>
                  <td>{p.materialName}</td>
                  <td>{p.quantity}</td>
                  <td>₹{p.unitPrice}</td>
                  <td><strong>₹{p.totalPrice?.toLocaleString('en-IN')}</strong></td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>
                  No purchases found within the selected date range ({startDate} to {endDate}).
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
