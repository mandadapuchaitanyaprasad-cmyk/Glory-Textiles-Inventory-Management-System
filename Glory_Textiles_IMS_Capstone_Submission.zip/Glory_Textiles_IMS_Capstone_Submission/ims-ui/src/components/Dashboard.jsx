import React from 'react';

export default function Dashboard({ purchases, vendors, materials, onNavigate }) {
  const totalValue = purchases.reduce((acc, curr) => acc + (curr.totalPrice || 0), 0);
  const totalVendors = vendors.length;
  const totalMaterials = materials.length;

  return (
    <div>
      {/* Top Stat Cards */}
      <div className="grid-stats">
        <div className="stat-card">
          <div className="stat-title">Total Inventory Expenditure</div>
          <div className="stat-value">₹{totalValue.toLocaleString('en-IN')}</div>
          <div className="stat-badge badge-emerald">↑ 14.2% vs last month</div>
        </div>

        <div className="stat-card">
          <div className="stat-title">Active Suppliers / Vendors</div>
          <div className="stat-value">{totalVendors}</div>
          <div className="stat-badge badge-purple">Integrated Microservices</div>
        </div>

        <div className="stat-card">
          <div className="stat-title">Material Stock Categories</div>
          <div className="stat-value">{totalMaterials}</div>
          <div className="stat-badge badge-cyan">Cotton, Silk, Denim & Synthetics</div>
        </div>

        <div className="stat-card">
          <div className="stat-title">Total Purchases Logged</div>
          <div className="stat-value">{purchases.length}</div>
          <div className="stat-badge badge-emerald">Microservice Synced</div>
        </div>
      </div>

      {/* Quick Action & Overview Panel */}
      <div className="panel-card">
        <div className="panel-title">
          <span>Recent Purchase Orders (IMS Microservice)</span>
          <button className="btn-primary" onClick={() => onNavigate('purchase')}>+ New Purchase Entry</button>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>PO ID</th>
                <th>Vendor</th>
                <th>Material</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Value</th>
                <th>Purchase Date</th>
              </tr>
            </thead>
            <tbody>
              {purchases.slice(0, 5).map((p) => (
                <tr key={p.purchaseId}>
                  <td><strong>#PO-{p.purchaseId}</strong></td>
                  <td>{p.vendorName}</td>
                  <td>{p.materialName}</td>
                  <td>{p.quantity}</td>
                  <td>₹{p.unitPrice}</td>
                  <td><strong>₹{p.totalPrice?.toLocaleString('en-IN')}</strong></td>
                  <td>{p.purchaseDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
