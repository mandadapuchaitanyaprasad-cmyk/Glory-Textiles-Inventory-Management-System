import React, { useState } from 'react';

export default function VendorReport({ purchases, vendors }) {
  const [selectedVendorId, setSelectedVendorId] = useState(vendors[0]?.vendorId || 101);

  const vendorPurchases = purchases.filter(p => Number(p.vendorId) === Number(selectedVendorId));
  const currentVendor = vendors.find(v => Number(v.vendorId) === Number(selectedVendorId));
  const totalVendorSpend = vendorPurchases.reduce((sum, p) => sum + (p.totalPrice || 0), 0);

  return (
    <div className="panel-card">
      <div className="panel-title">
        <span>Vendor Purchase History Report</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <label style={{ fontSize: '0.88rem', color: 'var(--text-muted)' }}>Select Vendor:</label>
          <select 
            className="form-select" 
            value={selectedVendorId} 
            onChange={(e) => setSelectedVendorId(e.target.value)}
            style={{ width: '260px' }}
          >
            {vendors.map(v => (
              <option key={v.vendorId} value={v.vendorId}>
                {v.vendorName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {currentVendor && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '16px',
          background: 'rgba(15, 23, 42, 0.6)',
          padding: '18px 24px',
          borderRadius: '12px',
          border: '1px solid var(--bg-card-border)',
          marginBottom: '20px'
        }}>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Vendor Name</div>
            <div style={{ fontWeight: '700', fontSize: '1.05rem' }}>{currentVendor.vendorName}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Contact Email</div>
            <div>{currentVendor.email || 'N/A'}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Location</div>
            <div>{currentVendor.city || 'N/A'}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Total Procured Value</div>
            <div style={{ fontWeight: '700', color: 'var(--accent-cyan)', fontSize: '1.1rem' }}>
              ₹{totalVendorSpend.toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      )}

      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Purchase ID</th>
              <th>Material Name</th>
              <th>Quantity</th>
              <th>Unit Price (₹)</th>
              <th>Total Amount (₹)</th>
              <th>Purchase Date</th>
            </tr>
          </thead>
          <tbody>
            {vendorPurchases.length > 0 ? (
              vendorPurchases.map(p => (
                <tr key={p.purchaseId}>
                  <td><strong>#PO-{p.purchaseId}</strong></td>
                  <td>{p.materialName}</td>
                  <td>{p.quantity}</td>
                  <td>₹{p.unitPrice}</td>
                  <td><strong>₹{p.totalPrice?.toLocaleString('en-IN')}</strong></td>
                  <td>{p.purchaseDate}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>
                  No purchase records found for this vendor.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
