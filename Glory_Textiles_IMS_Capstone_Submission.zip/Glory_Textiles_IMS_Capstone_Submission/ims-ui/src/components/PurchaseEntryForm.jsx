import React, { useState } from 'react';

export default function PurchaseEntryForm({ vendors, materials, onAddPurchase }) {
  const [selectedVendorId, setSelectedVendorId] = useState(vendors[0]?.vendorId || 101);
  const [selectedMaterialId, setSelectedMaterialId] = useState(materials[0]?.materialId || 201);
  const [quantity, setQuantity] = useState(100);
  const [unitPrice, setUnitPrice] = useState(materials[0]?.unitPrice || 450);
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [submittedMessage, setSubmittedMessage] = useState(null);

  const handleMaterialChange = (e) => {
    const matId = Number(e.target.value);
    setSelectedMaterialId(matId);
    const foundMat = materials.find(m => m.materialId === matId);
    if (foundMat && foundMat.unitPrice) {
      setUnitPrice(foundMat.unitPrice);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const vendorObj = vendors.find(v => v.vendorId === Number(selectedVendorId)) || { vendorName: 'Vardhman Textiles Ltd' };
    const matObj = materials.find(m => m.materialId === Number(selectedMaterialId)) || { materialName: 'Organic Egyptian Cotton' };

    const newEntry = {
      purchaseId: Math.floor(300 + Math.random() * 900),
      vendorId: Number(selectedVendorId),
      vendorName: vendorObj.vendorName,
      materialId: Number(selectedMaterialId),
      materialName: matObj.materialName,
      quantity: Number(quantity),
      unitPrice: Number(unitPrice),
      totalPrice: Number(quantity) * Number(unitPrice),
      purchaseDate: purchaseDate
    };

    onAddPurchase(newEntry);
    setSubmittedMessage(`Purchase Entry #${newEntry.purchaseId} logged successfully! Total: ₹${newEntry.totalPrice.toLocaleString('en-IN')}`);
    setTimeout(() => setSubmittedMessage(null), 4000);
  };

  return (
    <div className="panel-card">
      <div className="panel-title">Add New Material Purchase Entry</div>
      <p style={{ color: 'var(--text-muted)', marginBottom: '20px', fontSize: '0.9rem' }}>
        Record raw material inventory orders. Data connects to <code>vendor-service</code> and <code>material-service</code>.
      </p>

      {submittedMessage && (
        <div style={{
          padding: '14px 20px',
          borderRadius: '10px',
          background: 'rgba(16, 185, 129, 0.15)',
          border: '1px solid rgba(16, 185, 129, 0.4)',
          color: '#10b981',
          marginBottom: '20px',
          fontWeight: '600'
        }}>
          {submittedMessage}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-group">
            <label>Select Vendor (Vendor Service)</label>
            <select 
              className="form-select" 
              value={selectedVendorId} 
              onChange={(e) => setSelectedVendorId(e.target.value)}
            >
              {vendors.map(v => (
                <option key={v.vendorId} value={v.vendorId}>
                  {v.vendorName} ({v.city})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Select Material (Material Service)</label>
            <select 
              className="form-select" 
              value={selectedMaterialId} 
              onChange={handleMaterialChange}
            >
              {materials.map(m => (
                <option key={m.materialId} value={m.materialId}>
                  {m.materialName} - {m.materialCategory} ({m.unit})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Quantity Ordered</label>
            <input 
              type="number" 
              className="form-input" 
              min="1"
              value={quantity} 
              onChange={(e) => setQuantity(e.target.value)} 
              required
            />
          </div>

          <div className="form-group">
            <label>Unit Price (₹)</label>
            <input 
              type="number" 
              className="form-input" 
              value={unitPrice} 
              onChange={(e) => setUnitPrice(e.target.value)} 
              required
            />
          </div>

          <div className="form-group">
            <label>Total Price (Calculated)</label>
            <input 
              type="text" 
              className="form-input" 
              value={`₹${(Number(quantity) * Number(unitPrice)).toLocaleString('en-IN')}`} 
              disabled
              style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--accent-cyan)', fontWeight: '700' }}
            />
          </div>

          <div className="form-group">
            <label>Purchase Date</label>
            <input 
              type="date" 
              className="form-input" 
              value={purchaseDate} 
              onChange={(e) => setPurchaseDate(e.target.value)} 
              required
            />
          </div>
        </div>

        <button type="submit" className="btn-primary" style={{ minWidth: '200px' }}>
          Submit Purchase Entry
        </button>
      </form>
    </div>
  );
}
