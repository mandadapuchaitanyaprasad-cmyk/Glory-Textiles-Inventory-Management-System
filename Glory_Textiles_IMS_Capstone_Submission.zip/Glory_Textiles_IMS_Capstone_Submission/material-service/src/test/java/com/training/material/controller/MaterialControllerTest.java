package com.training.material.controller;

import com.training.material.model.Material;
import com.training.material.service.MaterialService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(MaterialController.class)
class MaterialControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MaterialService materialService;

    @Test
    void testWelcomeEndpoint() throws Exception {
        mockMvc.perform(get("/material/"))
                .andExpect(status().isOk())
                .andExpect(content().string("Material Service deployed successfully"));
    }

    @Test
    void testGetAllMaterials() throws Exception {
        Material m1 = new Material(201L, "Organic Egyptian Cotton", "Yarn", "Natural Fiber", "Kg", 450.00);
        Mockito.when(materialService.getAllMaterials()).thenReturn(Arrays.asList(m1));

        mockMvc.perform(get("/material/all"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetMaterialById() throws Exception {
        Material m1 = new Material(201L, "Organic Egyptian Cotton", "Yarn", "Natural Fiber", "Kg", 450.00);
        Mockito.when(materialService.getMaterialById(201L)).thenReturn(Optional.of(m1));

        mockMvc.perform(get("/material/201"))
                .andExpect(status().isOk());
    }
}
