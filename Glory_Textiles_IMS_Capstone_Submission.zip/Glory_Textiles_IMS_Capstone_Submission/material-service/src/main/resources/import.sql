INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (201, 'Organic Egyptian Cotton', 'Yarn', 'Natural Fiber', 'Kilogram (Kg)', 450.00);
INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (202, 'Mulberry Silk Thread', 'Yarn', 'Luxury Silk', 'Meters (m)', 1250.00);
INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (203, 'Polyester Blend Fabric', 'Fabric', 'Synthetic', 'Meters (m)', 180.00);
INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (204, 'Refined Denim Weave', 'Fabric', 'Woven Denim', 'Meters (m)', 320.00);
INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (205, 'Linen Flax Fibre', 'Raw Material', 'Plant Fiber', 'Kilogram (Kg)', 600.00);
INSERT INTO material (material_id, material_name, material_category, material_type, unit, unit_price) VALUES (206, 'Durable Nylon Thread', 'Accessories', 'Synthetic Thread', 'Spool', 95.00);
