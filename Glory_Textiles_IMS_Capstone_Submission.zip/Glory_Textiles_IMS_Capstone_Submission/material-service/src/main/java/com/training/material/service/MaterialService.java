package com.training.material.service;

import com.training.material.model.Material;
import com.training.material.repository.MaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MaterialService {

    private final MaterialRepository materialRepository;

    @Autowired
    public MaterialService(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    public List<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

    public Optional<Material> getMaterialById(Long materialId) {
        return materialRepository.findById(materialId);
    }

    public List<Material> getMaterialsByCategory(String category) {
        return materialRepository.findByMaterialCategory(category);
    }

    public Material saveMaterial(Material material) {
        return materialRepository.save(material);
    }

    public void deleteMaterial(Long materialId) {
        materialRepository.deleteById(materialId);
    }
}
