package com.training.material.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "material")
public class Material {

    @Id
    private Long materialId;
    private String materialName;
    private String materialCategory;
    private String materialType;
    private String unit;
    private Double unitPrice;

    public Material() {
    }

    public Material(Long materialId, String materialName, String materialCategory, String materialType, String unit, Double unitPrice) {
        this.materialId = materialId;
        this.materialName = materialName;
        this.materialCategory = materialCategory;
        this.materialType = materialType;
        this.unit = unit;
        this.unitPrice = unitPrice;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getMaterialCategory() {
        return materialCategory;
    }

    public void setMaterialCategory(String materialCategory) {
        this.materialCategory = materialCategory;
    }

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }
}
