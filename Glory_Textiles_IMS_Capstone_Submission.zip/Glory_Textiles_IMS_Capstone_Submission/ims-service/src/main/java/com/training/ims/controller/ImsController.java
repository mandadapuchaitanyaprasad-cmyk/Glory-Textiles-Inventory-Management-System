package com.training.ims.controller;

import com.training.ims.model.PurchaseEntry;
import com.training.ims.service.ImsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/inventory")
@CrossOrigin(origins = "*")
public class ImsController {

    private final ImsService imsService;

    @Autowired
    public ImsController(ImsService imsService) {
        this.imsService = imsService;
    }

    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Inventory Service is UP");
    }

    @GetMapping("/")
    public ResponseEntity<String> rootCheck() {
        return ResponseEntity.ok("Inventory Service is UP");
    }

    @GetMapping("/all")
    public ResponseEntity<List<PurchaseEntry>> getAllPurchases() {
        return ResponseEntity.ok(imsService.getAllPurchaseEntries());
    }

    @PostMapping("/purchase")
    public ResponseEntity<PurchaseEntry> createPurchaseEntry(@RequestBody PurchaseEntry entry) {
        PurchaseEntry created = imsService.savePurchaseEntry(entry);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/report/vendor/{vendorId}")
    public ResponseEntity<List<PurchaseEntry>> getReportByVendor(@PathVariable("vendorId") Long vendorId) {
        List<PurchaseEntry> report = imsService.getReportByVendor(vendorId);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/report/daterange")
    public ResponseEntity<List<PurchaseEntry>> getReportByDateRange(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        List<PurchaseEntry> report = imsService.getReportByDateRange(startDate, endDate);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/report/vendor-daterange")
    public ResponseEntity<List<PurchaseEntry>> getReportByVendorAndDateRange(
            @RequestParam("vendorId") Long vendorId,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        List<PurchaseEntry> report = imsService.getReportByVendorAndDateRange(vendorId, startDate, endDate);
        return ResponseEntity.ok(report);
    }
}
