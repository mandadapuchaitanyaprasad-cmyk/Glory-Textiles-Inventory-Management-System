package com.training.ims.service;

import com.training.ims.model.PurchaseEntry;
import com.training.ims.repository.PurchaseEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ImsService {

    private final PurchaseEntryRepository purchaseEntryRepository;

    @Autowired
    public ImsService(PurchaseEntryRepository purchaseEntryRepository) {
        this.purchaseEntryRepository = purchaseEntryRepository;
    }

    public List<PurchaseEntry> getAllPurchaseEntries() {
        return purchaseEntryRepository.findAll();
    }

    public Optional<PurchaseEntry> getPurchaseEntryById(Long id) {
        return purchaseEntryRepository.findById(id);
    }

    public PurchaseEntry savePurchaseEntry(PurchaseEntry entry) {
        if (entry.getQuantity() != null && entry.getUnitPrice() != null) {
            entry.setTotalPrice(entry.getQuantity() * entry.getUnitPrice());
        }
        if (entry.getPurchaseDate() == null) {
            entry.setPurchaseDate(LocalDate.now());
        }
        return purchaseEntryRepository.save(entry);
    }

    public List<PurchaseEntry> getReportByVendor(Long vendorId) {
        return purchaseEntryRepository.findByVendorId(vendorId);
    }

    public List<PurchaseEntry> getReportByDateRange(LocalDate startDate, LocalDate endDate) {
        return purchaseEntryRepository.findByPurchaseDateBetween(startDate, endDate);
    }

    public List<PurchaseEntry> getReportByVendorAndDateRange(Long vendorId, LocalDate startDate, LocalDate endDate) {
        return purchaseEntryRepository.findByVendorIdAndPurchaseDateBetween(vendorId, startDate, endDate);
    }
}
