package com.training.ims.repository;

import com.training.ims.model.PurchaseEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PurchaseEntryRepository extends JpaRepository<PurchaseEntry, Long> {
    List<PurchaseEntry> findByVendorId(Long vendorId);

    List<PurchaseEntry> findByPurchaseDateBetween(LocalDate startDate, LocalDate endDate);

    List<PurchaseEntry> findByVendorIdAndPurchaseDateBetween(Long vendorId, LocalDate startDate, LocalDate endDate);
}
