package com.training.ims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}
