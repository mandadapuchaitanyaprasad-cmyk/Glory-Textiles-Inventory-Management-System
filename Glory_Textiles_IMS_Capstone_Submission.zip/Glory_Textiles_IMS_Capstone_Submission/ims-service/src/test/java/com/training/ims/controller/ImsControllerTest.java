package com.training.ims.controller;

import com.training.ims.model.PurchaseEntry;
import com.training.ims.service.ImsService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ImsController.class)
class ImsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ImsService imsService;

    @Test
    void testHealthCheck() throws Exception {
        mockMvc.perform(get("/inventory/health"))
                .andExpect(status().isOk())
                .andExpect(content().string("Inventory Service is UP"));
    }

    @Test
    void testGetAllPurchases() throws Exception {
        PurchaseEntry p1 = new PurchaseEntry(301L, 101L, "Vardhman Textiles", 201L, "Cotton", 100.0, 450.0, 45000.0, LocalDate.now());
        Mockito.when(imsService.getAllPurchaseEntries()).thenReturn(Arrays.asList(p1));

        mockMvc.perform(get("/inventory/all"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetReportByVendor() throws Exception {
        PurchaseEntry p1 = new PurchaseEntry(301L, 101L, "Vardhman Textiles", 201L, "Cotton", 100.0, 450.0, 45000.0, LocalDate.now());
        Mockito.when(imsService.getReportByVendor(101L)).thenReturn(Arrays.asList(p1));

        mockMvc.perform(get("/inventory/report/vendor/101"))
                .andExpect(status().isOk());
    }
}
